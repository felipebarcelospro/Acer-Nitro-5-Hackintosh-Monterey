## INSTALL GUIDE

1º STEP - Open terminal on folder;
2º STEP - Run "sudo ./uninstall.sh";
3º STEP - Run "sudo ./install.sh";
4º STEP - Run "hda-verb 0x19 SET_PIN_WIDGET_CONTROL 0x25";
